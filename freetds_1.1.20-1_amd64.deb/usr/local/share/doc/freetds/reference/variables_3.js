var searchData=
[
  ['database',['database',['../a01170.html#ad05b5a83816aee8ff9858ddb1eb172b8',1,'tds_env']]],
  ['date',['date',['../a01086.html#a4697c11cf7da815856eb96bae4d57bac',1,'TDS_DATETIMEALL::date()'],['../a01290.html#afa93266cde7ab536615bca3d904aabed',1,'DBDATETIMEALL::date()']]],
  ['day',['day',['../a01090.html#a82d0cf263d8d4a3abcf84b9a146ddf83',1,'tdsdaterec']]],
  ['dayofyear',['dayofyear',['../a01090.html#a3f7925156708744d28016aacb90b6093',1,'tdsdaterec']]],
  ['db_5ffilename',['db_filename',['../a01110.html#a425f8ddd194f897f185d9f4d5e0618c2',1,'tds_login']]],
  ['decimicrosecond',['decimicrosecond',['../a01090.html#a838e73fd12eec9e3b5368316198f4762',1,'tdsdaterec']]],
  ['defer_5fclose',['defer_close',['../a01166.html#a411e76370c635dfabe9b5941cdd3180f',1,'tds_cursor::defer_close()'],['../a01174.html#a744986c76b9b09f29325a1e0664b0e9a',1,'tds_dynamic::defer_close()']]],
  ['dsn',['dsn',['../a00658.html#acd76726add649629f26f1f1754fe48cf',1,'DSNINFO']]],
  ['dyns',['dyns',['../a01198.html#a7dc98cfe507c626073b6e76985a06a8a',1,'tds_connection']]]
];
