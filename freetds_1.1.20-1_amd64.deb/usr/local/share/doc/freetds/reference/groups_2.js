var searchData=
[
  ['configuration',['Configuration',['../a00550.html',1,'']]],
  ['charset_20conversion',['Charset conversion',['../a00552.html',1,'']]],
  ['conversion',['Conversion',['../a00551.html',1,'']]]
];
