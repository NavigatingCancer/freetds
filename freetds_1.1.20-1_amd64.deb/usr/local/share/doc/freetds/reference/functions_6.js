var searchData=
[
  ['read_5fand_5fconvert',['read_and_convert',['../a00555.html#ga676c4dee6522815b16fdc8e448e43590',1,'read.c']]],
  ['rtrim',['rtrim',['../a00542.html#ga4d5be57b25a0654e2170fd656dc35489',1,'bcp.c']]]
];
