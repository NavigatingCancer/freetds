var searchData=
[
  ['has_5fstatus',['has_status',['../a01202.html#acd5eeef948380cd1b8abb132a417b2bf',1,'tds_socket']]],
  ['hour',['hour',['../a01090.html#ae9f0348efe607ac7333eac841be46333',1,'tdsdaterec']]]
];
