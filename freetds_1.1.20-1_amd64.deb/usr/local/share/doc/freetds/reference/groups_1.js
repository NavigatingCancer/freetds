var searchData=
[
  ['bulk_20copy_20functions',['Bulk copy functions',['../a00541.html',1,'']]]
];
