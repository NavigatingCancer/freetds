var searchData=
[
  ['minute',['minute',['../a01090.html#a81d1931139497023deb1bb75dc0aae7a',1,'tdsdaterec']]],
  ['month',['month',['../a01090.html#af1542b5698f668f7df650b20fa27c177',1,'tdsdaterec']]],
  ['msdblib',['msdblib',['../a00926.html#af3aab1ff30d324143f440bcd9f60d1c3',1,'tds_dblib_dbprocess']]]
];
