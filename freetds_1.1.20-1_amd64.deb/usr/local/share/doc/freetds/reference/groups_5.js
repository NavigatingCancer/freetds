var searchData=
[
  ['libtds_20api',['LibTDS API',['../a00558.html',1,'']]]
];
