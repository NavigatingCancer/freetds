var searchData=
[
  ['dblib_5ferror_5fmessage',['DBLIB_ERROR_MESSAGE',['../a00545.html#ga73ccf3a130f836159e43074544f338e3',1,'dblib.c']]],
  ['dblibcontext',['DBLIBCONTEXT',['../a00077.html#ac34310fe36604ce96b30f66427b093ef',1,'dblib.c']]],
  ['dstr',['DSTR',['../a00557.html#gafddddf5bd7ad223cadee3d3bdc899954',1,'string.h']]]
];
