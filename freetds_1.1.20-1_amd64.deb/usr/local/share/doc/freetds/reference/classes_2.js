var searchData=
[
  ['bcp_5fhostcolinfo',['BCP_HOSTCOLINFO',['../a00902.html',1,'']]],
  ['bcp_5fhostfileinfo',['BCP_HOSTFILEINFO',['../a00906.html',1,'']]]
];
