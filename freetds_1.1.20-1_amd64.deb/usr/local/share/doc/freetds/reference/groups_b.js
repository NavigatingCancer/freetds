var searchData=
[
  ['remote_20procedure_20functions',['Remote Procedure functions',['../a00540.html',1,'']]],
  ['results_20processing',['Results processing',['../a00556.html',1,'']]]
];
