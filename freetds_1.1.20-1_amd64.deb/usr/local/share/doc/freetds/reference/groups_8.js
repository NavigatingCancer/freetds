var searchData=
[
  ['odbc_20api',['ODBC API',['../a00547.html',1,'']]],
  ['odbc_20utility',['ODBC utility',['../a00548.html',1,'']]]
];
