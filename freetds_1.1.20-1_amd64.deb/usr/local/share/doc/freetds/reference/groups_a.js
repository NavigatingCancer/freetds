var searchData=
[
  ['query',['Query',['../a00554.html',1,'']]]
];
