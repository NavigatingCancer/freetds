var searchData=
[
  ['bcp_5fhostcolinfo',['BCP_HOSTCOLINFO',['../a00877.html',1,'']]],
  ['bcp_5fhostfileinfo',['BCP_HOSTFILEINFO',['../a00881.html',1,'']]]
];
