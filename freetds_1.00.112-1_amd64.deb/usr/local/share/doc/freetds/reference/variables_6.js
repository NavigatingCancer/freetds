var searchData=
[
  ['has_5fstatus',['has_status',['../a01193.html#a75ab58b901d242ae27e36bd39b23a54f',1,'tds_socket']]],
  ['hour',['hour',['../a01081.html#ae9f0348efe607ac7333eac841be46333',1,'tdsdaterec']]]
];
