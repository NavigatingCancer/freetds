var searchData=
[
  ['quarter',['quarter',['../a01081.html#aa0efc92bb0079287e043bb2c46c4603d',1,'tdsdaterec']]],
  ['query',['query',['../a00993.html#aaf4c8eb3163d2261ce6ce90118a70aec',1,'_hstmt::query()'],['../a01157.html#aeec2a01af48693b8b22449f15725d502',1,'tds_cursor::query()'],['../a01165.html#a1cee141e5f7045e691eec830cec1c158',1,'tds_dynamic::query()'],['../a00533.html',1,'(Global Namespace)']]],
  ['query_5ftimeout',['query_timeout',['../a00585.html#abf71abb24c7afea7dd7ef440048ea4c9',1,'dblib_context']]]
];
