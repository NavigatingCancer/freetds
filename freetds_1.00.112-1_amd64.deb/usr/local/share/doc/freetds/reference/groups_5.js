var searchData=
[
  ['libtds_20api',['LibTDS API',['../a00537.html',1,'']]]
];
