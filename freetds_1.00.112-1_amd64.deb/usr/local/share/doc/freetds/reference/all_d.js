var searchData=
[
  ['objectinfo',['OBJECTINFO',['../a00569.html',1,'']]],
  ['odbc_20api',['ODBC API',['../a00526.html',1,'']]],
  ['odbc_5fc_5fto_5fserver_5ftype',['odbc_c_to_server_type',['../a00527.html#ga3f0a413cea480a38d3d9b90c95515f6b',1,'odbc_c_to_server_type(int c_type):&#160;odbc_util.c'],['../a00527.html#ga3f0a413cea480a38d3d9b90c95515f6b',1,'odbc_c_to_server_type(int c_type):&#160;odbc_util.c']]],
  ['odbc_5fget_5fparam_5flen',['odbc_get_param_len',['../a00527.html#ga35028e8de1d50dc51ccef1d645c55e2a',1,'odbc_get_param_len(const struct _drecord *drec_axd, const struct _drecord *drec_ixd, const TDS_DESC *axd, unsigned int n_row):&#160;odbc_util.c'],['../a00527.html#ga35028e8de1d50dc51ccef1d645c55e2a',1,'odbc_get_param_len(const struct _drecord *drec_axd, const struct _drecord *drec_ixd, const TDS_DESC *axd, unsigned int n_row):&#160;odbc_util.c']]],
  ['odbc_5frdbms_5fversion',['odbc_rdbms_version',['../a00527.html#gae85ff7fb2002b5a7abc04fbee79e5525',1,'odbc_rdbms_version(TDSSOCKET *tds, char *pversion_string):&#160;odbc_util.c'],['../a00527.html#gae85ff7fb2002b5a7abc04fbee79e5525',1,'odbc_rdbms_version(TDSSOCKET *tds_socket, char *pversion_string):&#160;odbc_util.c']]],
  ['odbc_5fset_5fconcise_5fc_5ftype',['odbc_set_concise_c_type',['../a00527.html#ga128f6b09cde0af252370ba89cfa1fb78',1,'odbc_set_concise_c_type(SQLSMALLINT concise_type, struct _drecord *drec, int check_only):&#160;odbc_util.c'],['../a00527.html#ga128f6b09cde0af252370ba89cfa1fb78',1,'odbc_set_concise_c_type(SQLSMALLINT concise_type, struct _drecord *drec, int check_only):&#160;odbc_util.c']]],
  ['odbc_5fset_5fconcise_5fsql_5ftype',['odbc_set_concise_sql_type',['../a00527.html#ga125574bd2de677438909612db80041ea',1,'odbc_set_concise_sql_type(SQLSMALLINT concise_type, struct _drecord *drec, int check_only):&#160;odbc_util.c'],['../a00527.html#ga125574bd2de677438909612db80041ea',1,'odbc_set_concise_sql_type(SQLSMALLINT concise_type, struct _drecord *drec, int check_only):&#160;odbc_util.c']]],
  ['odbc_5fset_5fstring_5fflag',['odbc_set_string_flag',['../a00527.html#gadba4490bf3183799a70c9e2f44fab331',1,'odbc_set_string_flag(TDS_DBC *dbc, SQLPOINTER buffer, SQLINTEGER cbBuffer, void FAR *pcbBuffer, const char *s, int len, int flag):&#160;odbc_util.c'],['../a00527.html#gadba4490bf3183799a70c9e2f44fab331',1,'odbc_set_string_flag(TDS_DBC *dbc, SQLPOINTER buffer, SQLINTEGER cbBuffer, void FAR *pcbBuffer, const char *s, int len, int flag):&#160;odbc_util.c']]],
  ['odbc_20utility',['ODBC utility',['../a00527.html',1,'']]],
  ['offset',['offset',['../a01077.html#a76f4cbcb3bc7c10b3616579ec7861f58',1,'TDS_DATETIMEALL::offset()'],['../a01265.html#a13159d738e1d0b582a3a731123feb5f3',1,'DBDATETIMEALL::offset()']]],
  ['options',['options',['../a01157.html#a1be9f69f84a6d83ce86380c33a2bf9f8',1,'tds_cursor']]],
  ['origdsn',['origdsn',['../a00637.html#a8127a82b8c4130820a4c44f88eda8bcf',1,'DSNINFO']]],
  ['out_5fbuf',['out_buf',['../a01193.html#ad6b5121e435d22d640a645b98833cb9d',1,'tds_socket']]],
  ['out_5fbuf_5fmax',['out_buf_max',['../a01193.html#ae6fc66be718f3211fac3b835557e330e',1,'tds_socket']]],
  ['out_5fflag',['out_flag',['../a01193.html#a9bb663ee7c71f56f1602cbfcd993018c',1,'tds_socket']]],
  ['out_5fpos',['out_pos',['../a01193.html#a426adbd80f29f477377e42e8f78d3ff0',1,'tds_socket']]]
];
