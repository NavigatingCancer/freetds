var searchData=
[
  ['year',['year',['../a01081.html#a5a6a5b0180c3db53acbda61dd570d70f',1,'tdsdaterec']]]
];
