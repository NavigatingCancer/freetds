var searchData=
[
  ['odbc_20api',['ODBC API',['../a00526.html',1,'']]],
  ['odbc_20utility',['ODBC utility',['../a00527.html',1,'']]]
];
